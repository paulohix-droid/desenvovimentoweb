export interface ItemCesta {
  id: number;
  produto: string;
  quantidade: number;
  preco: number;
}