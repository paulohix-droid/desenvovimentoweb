import { Component } from '@angular/core';
import { BarraBuscaComponent } from '../barra-busca/barra-busca';

@Component({
  imports: [BarraBuscaComponent],
  selector: 'app-topo',
  styleUrl: './topo.css',
  templateUrl: './topo.html',
})
export class Topo {}
